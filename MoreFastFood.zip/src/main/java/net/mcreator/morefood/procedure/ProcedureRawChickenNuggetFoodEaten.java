package net.mcreator.morefood.procedure;

import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.mcreator.morefood.ElementsMoreFood;

@ElementsMoreFood.ModElement.Tag
public class ProcedureRawChickenNuggetFoodEaten extends ElementsMoreFood.ModElement {
	public ProcedureRawChickenNuggetFoodEaten(ElementsMoreFood instance) {
		super(instance, 7);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure RawChickenNuggetFoodEaten!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((Math.random() < 0.35)) {
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.HUNGER, (int) 80, (int) 1));
		}
	}
}

package net.mcreator.morefood.procedure;

import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.mcreator.morefood.ElementsMoreFood;

@ElementsMoreFood.ModElement.Tag
public class ProcedureRawHamburgerFoodEaten extends ElementsMoreFood.ModElement {
	public ProcedureRawHamburgerFoodEaten(ElementsMoreFood instance) {
		super(instance, 3);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure RawHamburgerFoodEaten!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((Math.random() < 0.35)) {
			if (entity instanceof EntityLivingBase)
				((EntityLivingBase) entity).addPotionEffect(new PotionEffect(MobEffects.HUNGER, (int) 80, (int) 1));
		}
	}
}

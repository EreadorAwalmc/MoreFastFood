
package net.mcreator.morefood.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.morefood.item.ItemRawHamburger;
import net.mcreator.morefood.item.ItemHamburger;
import net.mcreator.morefood.ElementsMoreFood;

@ElementsMoreFood.ModElement.Tag
public class RecipeTohamburger extends ElementsMoreFood.ModElement {
	public RecipeTohamburger(ElementsMoreFood instance) {
		super(instance, 6);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemRawHamburger.block, (int) (1)), new ItemStack(ItemHamburger.block, (int) (1)), 1F);
	}
}

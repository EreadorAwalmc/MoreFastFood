
package net.mcreator.morefood.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.morefood.item.ItemRawChickenNugget;
import net.mcreator.morefood.item.ItemChickenNugget;
import net.mcreator.morefood.ElementsMoreFood;

@ElementsMoreFood.ModElement.Tag
public class RecipeTCNT extends ElementsMoreFood.ModElement {
	public RecipeTCNT(ElementsMoreFood instance) {
		super(instance, 11);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemRawChickenNugget.block, (int) (1)), new ItemStack(ItemChickenNugget.block, (int) (1)), 1F);
	}
}
